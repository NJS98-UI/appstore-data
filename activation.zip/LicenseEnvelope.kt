package com.sky22333.skyadb.activation

import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object LicenseEnvelope {
    private const val ENCRYPTED_SCHEMA = "license_v3_encrypted"
    private const val GCM_TAG_BITS = 128
    private val KEY_MASK = byteArrayOf(
        0x4D.toByte(), 0x21.toByte(), 0x7A.toByte(), 0x13.toByte(), 0x5C.toByte(), 0x08.toByte(),
        0x2F.toByte(), 0x6E.toByte(), 0x19.toByte(), 0x33.toByte(), 0x44.toByte(),
    )
    private val KEY_DATA = byteArrayOf(
        0x00.toByte(), 0x48.toByte(), 0x14.toByte(), 0x74.toByte(), 0x1F.toByte(), 0x60.toByte(), 0x4A.toByte(), 0x00.toByte(),
        0x34.toByte(), 0x7F.toByte(), 0x2D.toByte(), 0x2E.toByte(), 0x44.toByte(), 0x14.toByte(), 0x60.toByte(), 0x39.toByte(),
        0x25.toByte(), 0x7B.toByte(), 0x1C.toByte(), 0x78.toByte(), 0x5D.toByte(), 0x37.toByte(), 0x3D.toByte(), 0x4E.toByte(),
        0x08.toByte(), 0x67.toByte(), 0x71.toByte(), 0x7E.toByte(), 0x1C.toByte(), 0x54.toByte(), 0x23.toByte(), 0x01.toByte(),
        0x74.toByte(), 0x7F.toByte(), 0x17.toByte(), 0x40.toByte(), 0x29.toByte(), 0x1D.toByte(), 0x78.toByte(), 0x46.toByte(),
        0x3E.toByte(), 0x78.toByte(), 0x4A.toByte(), 0x28.toByte(), 0x22.toByte(), 0x40.toByte(), 0x1E.toByte(),
    )

    fun decodeTransportBody(body: String): String {
        val trimmed = body.trim()
        val apiContent = tryDecodeGitHubContent(trimmed)
        return decodeLicenseContent(apiContent ?: trimmed)
    }

    private fun tryDecodeGitHubContent(body: String): String? {
        return try {
            val root = JSONObject(body)
            val content = root.optString("content", "")
            if (content.isBlank()) return null
            val normalized = content.replace("\n", "")
            String(Base64.decode(normalized, Base64.DEFAULT), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    private fun decodeLicenseContent(content: String): String {
        val trimmed = content.trim()
        return try {
            val root = JSONObject(trimmed)
            if (root.optString("schema") != ENCRYPTED_SCHEMA) return trimmed
            val iv = Base64.decode(root.optString("iv"), Base64.DEFAULT)
            val payload = Base64.decode(root.optString("payload"), Base64.DEFAULT)
            decrypt(iv, payload)
        } catch (_: Exception) {
            trimmed
        }
    }

    private fun decrypt(iv: ByteArray, payload: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, keySpec(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return String(cipher.doFinal(payload), Charsets.UTF_8)
    }

    private fun keySpec(): SecretKeySpec {
        val material = ByteArray(KEY_DATA.size) { i ->
            (KEY_DATA[i].toInt() xor KEY_MASK[i % KEY_MASK.size].toInt()).toByte()
        }
        val key = MessageDigest.getInstance("SHA-256").digest(material)
        return SecretKeySpec(key, "AES")
    }
}
