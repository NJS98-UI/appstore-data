package com.sky22333.skyadb.activation

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * HTTP 传输层：主 App 只做公开只读 API GET。
 *
 * GitHub API 返回的文件内容由 LicenseEnvelope 做业务层解密。
 */
class NativeHttpHelper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "Net"
        private const val UA = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36"
    }

    fun getPublic(url: String): String? {
        return try {
            Log.i(TAG, "GET $url")
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Cache-Control", "no-cache, no-store")
                .header("Pragma", "no-cache")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                Log.i(TAG, "HTTP ${resp.code}")
                if (resp.isSuccessful) resp.body?.string() else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "GET fail: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }
}
