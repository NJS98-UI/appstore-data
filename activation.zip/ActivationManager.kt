package com.sky22333.skyadb.activation

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * 激活管理器：纯 DEX 只读验签实现。
 *
 * 主 App 只读取已签名授权状态，不执行云端写入。
 * 云端授权记录由管理员激活工具签名生成，主 App 仅使用公钥验签。
 */
class ActivationManager(private val context: Context) {

    private val net = NativeHttpHelper()

    companion object {
        private const val TAG = "ActivationManager"
        private const val MAX_RETRIES = 3
        private const val RETRY_DELAY_MS = 2000L
        private const val PREFS_NAME = "activation_cache"
        private const val KEY_TYPE = "type"
        private const val KEY_REMAINING = "remaining"
        private const val KEY_CODE = "code"
        private const val KEY_CACHED_AT = "cached_at"
    }

    private suspend fun <T> retryNetwork(name: String, block: suspend () -> T?): T? {
        repeat(MAX_RETRIES) { attempt ->
            val result = block()
            if (result != null) return result
            Log.w(TAG, "$name 第${attempt + 1}次失败, 共$MAX_RETRIES 次")
            if (attempt < MAX_RETRIES - 1) {
                kotlinx.coroutines.delay(RETRY_DELAY_MS)
            }
        }
        return null
    }

    sealed class ActivationStatus {
        data class Valid(val type: String, val remainingSeconds: Long, val code: String) : ActivationStatus()
        object NotActivated : ActivationStatus()
        data class Expired(val code: String) : ActivationStatus()
        data class Error(val message: String) : ActivationStatus()
    }

    sealed class ActivateResult {
        data class Success(val type: String, val duration: Long) : ActivateResult()
        data class Error(val message: String) : ActivateResult()
    }

    data class ContactInfo(
        val qq: String,
        val douyin: String,
        val qqHandle: String,
        val author: String,
    )

    fun getMachineCode(): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val model = Build.MODEL ?: "unknown"
        val manufacturer = Build.MANUFACTURER ?: "unknown"
        return SecureCore.genMachineCode("$androidId|$model|$manufacturer")
    }

    fun getContactInfo(): ContactInfo {
        return try {
            val json = JSONObject(SecureCore.getContactInfo())
            ContactInfo(
                qq = json.optString("qq", "460290139"),
                douyin = json.optString("douyin", "我的捷途X70L"),
                qqHandle = json.optString("qqHandle", "简单点"),
                author = json.optString("author", "傲慢与偏见"),
            )
        } catch (e: Exception) {
            ContactInfo("460290139", "我的捷途X70L", "简单点", "傲慢与偏见")
        }
    }

    private fun saveCachedActivation(status: ActivationStatus.Valid) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_TYPE, status.type)
                .putLong(KEY_REMAINING, status.remainingSeconds)
                .putString(KEY_CODE, status.code)
                .putLong(KEY_CACHED_AT, System.currentTimeMillis() / 1000)
                .apply()
        } catch (e: Exception) {
            Log.e(TAG, "保存缓存失败", e)
        }
    }

    private fun clearCachedActivation() {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
        } catch (e: Exception) {
            Log.e(TAG, "清除缓存失败", e)
        }
    }

    suspend fun checkCloudActivation(): ActivationStatus = withContext(Dispatchers.IO) {
        val mc = getMachineCode()
        if (mc.isEmpty()) return@withContext ActivationStatus.Error("无法获取设备信息")

        try {
            val urls = listOf(
                appendNoCache(SecureCore.getRawUrl()),
                appendNoCache(SecureCore.getRawFallbackUrl()),
            )
            val encryptedBody = retryNetwork("检查授权") {
                for (url in urls) {
                    val body = net.getPublic(url)
                    if (body != null) return@retryNetwork body
                }
                null
            }
                ?: return@withContext ActivationStatus.Error("网络连接失败，请检查网络后重试")
            val json = LicenseEnvelope.decodeTransportBody(encryptedBody)

            val result = LicenseVerifier.checkStatus(json, mc)
            when (result.state) {
                "VALID" -> {
                    val status = ActivationStatus.Valid(result.type, result.remaining, result.licenseId)
                    saveCachedActivation(status)
                    status
                }
                "EXPIRED" -> {
                    clearCachedActivation()
                    ActivationStatus.Expired(result.licenseId)
                }
                else -> {
                    clearCachedActivation()
                    ActivationStatus.NotActivated
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "检查授权异常", e)
            ActivationStatus.Error("授权验证异常: ${e.message}")
        }
    }

    suspend fun activate(): ActivateResult = withContext(Dispatchers.IO) {
        when (val status = checkCloudActivation()) {
            is ActivationStatus.Valid -> ActivateResult.Success(status.type, status.remainingSeconds)
            is ActivationStatus.Expired -> ActivateResult.Error("授权已过期")
            is ActivationStatus.NotActivated -> ActivateResult.Error("未找到本机授权，请复制机器码联系作者开通")
            is ActivationStatus.Error -> ActivateResult.Error(status.message)
        }
    }

    private fun appendNoCache(url: String): String {
        val sep = if (url.contains("?")) "&" else "?"
        return "$url${sep}t=${System.currentTimeMillis() / 1000}"
    }
}
