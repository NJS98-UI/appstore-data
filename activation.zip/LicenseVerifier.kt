package com.sky22333.skyadb.activation

import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Locale

/**
 * 只读授权验签器。
 *
 * 主 App 仅内置公钥，不能生成或篡改授权。
 * 授权记录由管理员激活工具签名后写入云端 JSON。
 */
object LicenseVerifier {
    private const val PUBLIC_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0kWLJI59zfx/l/TICiWPzsRThRwM9+1NPdxVcfzD2CV1tM+9IbhV1YbRkLBTPJDb2nVTDy6KWcarTiH2zbZjvmswFVEldM2z6lNz7Yyh82hG5g8D/2GpMyJVcRmtjb7sGlq5nKqsTnRWWUaXFWfojm/PgZF0SmBe8Gw+z7YhWZPDyaiJ5HTdl0h9JI4H1nSzkJVhWYK99SJPiKS0pQ+pYrwSje66H1C2Ue6CoSPPH2gouLb7h9cwMezTO3+tP6fdE4k4R6oY3Y4FjC0m4fNnPBVTOGZfD2oLquyH1Pm0Y/re5rQh6+vSTkWY2qtJ2lHvvRu0gEDI0HEGALTYusUaIwIDAQAB"
    private const val SIGN_ALGORITHM = "SHA256withRSA"
    private const val LICENSE_SCHEMA = "license_v2"

    data class Result(
        val state: String,
        val type: String = "",
        val remaining: Long = 0L,
        val licenseId: String = "",
    )

    fun checkStatus(jsonStr: String, machineCode: String): Result {
        return try {
            val root = JSONObject(jsonStr)
            val licenses = root.optJSONArray("licenses") ?: return Result("NOT_ACTIVATED")
            val hash = machineHash(machineCode)
            val now = System.currentTimeMillis() / 1000

            for (i in 0 until licenses.length()) {
                val obj = licenses.optJSONObject(i) ?: continue
                if (obj.optString("machine_hash") != hash) continue
                if (!verify(obj)) continue

                val status = obj.optString("status", "valid")
                val licenseId = obj.optString("license_id", "")
                if (status != "valid") return Result("EXPIRED", licenseId = licenseId)

                val type = obj.optString("type", "")
                val duration = obj.optLong("duration", 0L)
                val expiresAt = obj.optLong("expires_at", 0L)

                if (type == "permanent" || expiresAt == -1L || duration == -1L) {
                    return Result("VALID", "permanent", -1L, licenseId)
                }

                val remaining = expiresAt - now
                if (remaining <= 0L) {
                    return Result("EXPIRED", type, 0L, licenseId)
                }
                return Result("VALID", "time", remaining, licenseId)
            }
            Result("NOT_ACTIVATED")
        } catch (_: Exception) {
            Result("NOT_ACTIVATED")
        }
    }

    private fun machineHash(machineCode: String): String {
        val normalized = machineCode.trim().uppercase(Locale.US)
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun verify(obj: JSONObject): Boolean {
        return try {
            val signatureText = obj.optString("signature", "")
            if (signatureText.isEmpty()) return false

            val publicKey = KeyFactory.getInstance("RSA")
                .generatePublic(X509EncodedKeySpec(Base64.decode(PUBLIC_KEY_B64, Base64.DEFAULT)))
            val signature = Signature.getInstance(SIGN_ALGORITHM)
            signature.initVerify(publicKey)
            signature.update(canonical(obj).toByteArray(Charsets.UTF_8))
            signature.verify(Base64.decode(signatureText, Base64.DEFAULT))
        } catch (_: Exception) {
            false
        }
    }

    private fun canonical(obj: JSONObject): String {
        return listOf(
            LICENSE_SCHEMA,
            obj.optString("license_id", ""),
            obj.optString("machine_hash", ""),
            obj.optString("type", ""),
            obj.optLong("duration", 0L).toString(),
            obj.optLong("issued_at", 0L).toString(),
            obj.optLong("expires_at", 0L).toString(),
            obj.optString("status", "valid"),
        ).joinToString("|")
    }
}
